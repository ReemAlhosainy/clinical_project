#include "STD_Types.h"
#include <stdlib.h>
#include <stdio.h>
#include"func_int.h"

void passfunc(u32 pass)
{
	
	u8 c,flaag=0;u32 id;
	switch(pass)
	{
		case 1234:
		while(flaag==0){
		printf("the patient ID is :   ");
        fflush(stdout);
		scanf("%d",&id);
		
		printf("What do you wanna to do?\n");
		printf("If you wanna to add new patient record enter 1\n");
		printf("If you wanna to edit patient record enter 2\n");
		printf("If you wanna to reserve a slot with the doctor enter 3\n");
		printf("If you wanna to cancel reservation enter 4\n");	
		printf("Your choice is :   ");
		fflush(stdout);
		scanf("%d",&c);
			
		switch(c){
			case 1:
			addnew(id);
			flaag=1;
			break;
			case 2:
			edit(id);
			flaag=1;
			break;
			case 3:
			reserve(id);
			flaag=1;
			break;
			case 4:
			cancel(id);
			flaag=1;
			break;
			default:
			printf("Invalid!! Please Read instructions and Try again\n");		
            break;
		}
		break;	
		default:
		for(u8 i=0;i<3;i++)
		{
			printf("The password is uncorrect! Please try again\n");
			fflush(stdout);
			scanf("%d",&pass);
			if(pass==1234){passfunc(1234);   break;}
			if (i==1){printf("No more trials...Good Bye\n"); break;}
		}
	}
	}
}

void adminMode(void)
{u32 pas;u8 Id;
u8 flag=1;
	 printf("You are now in admin node\n");
		printf("OK ^ ^ Can you Enter the password ");
    	fflush(stdout);
    	scanf("%d",&pas);		
		passfunc(pas);
		flag=0;
}
void userMode()
{	u8 cho;
u8 Id;u8 flag=1;
  printf("You are now in user mode\n");
		printf("What do you wanna to do?\n");
        printf("If you wanna to view a patient record Enter 1\n "); 
	    printf("If you wanna to view all today patient reservation Enter 2\n "); 
        printf("Your choice is :   ");
     	fflush(stdout);
	    scanf("%d",&cho);
        switch(cho)
		{
			case 1:
		printf("the patient ID is :   ");
        fflush(stdout);
		scanf("%d",&Id);			
			viewOnePat(); 
			break;
			case 2: PRintTodayRes();  break;
			
		}		
		flag=0;	
}