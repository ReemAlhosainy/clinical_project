#ifndef STD_Types
void passfunc(u32 pass);
void cancel(u32 _id);
void addnew(u32 id);
void reserve(u32 _id);
void edit(u32 id);
void PRintTodayRes(void);
void viewOnePat(void);
void addNewPet(u32 id, u8 name[51],u8 gender[7],u8 age);
void adminMode(void);
void userMode(void);

#define S_2      0
#define S_2_30   1
#define S_3      2
#define S_3_30   3
#define S_4      4
#define S_4_30   5

/* 1- Data Type for node */

typedef struct node_type node;
struct node_type
{
	u8 age;
	u8 gender[7];
	 u8 name[51];
	u32 value;
	node*next;
};
struct patient
{
	u8 state;
	u32 id;
};
struct patient arrs[6];
	





#endif