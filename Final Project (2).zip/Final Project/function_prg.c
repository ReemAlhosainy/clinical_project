#include "STD_Types.h"
#include <stdlib.h>
#include <stdio.h>
#include "func_int.h"
#include<conio.h>
#include <string.h>

node head;
node*current=NULL;node*prev=NULL;
u32 i=0,value,pos;u32 ListLength=0;

void viewOnePat()
{
			printf("\n\n----------------------\n");
	/* at lease 1 node is created */
	if (ListLength > 0) {
		node *Last = &head;
		u32 i = 1;
		/* Print the list head */
			printf("%d- name is %s   ,ID is %d    ,Gender is %s \n", i,Last->name,Last -> value,Last->gender);
		/* Print all nodes util you find the last node
		which has the next pointer equals to NULL  */
		while ((Last -> next) != NULL){
			i++;
			Last = Last -> next; /* Move to next node */
			printf("%d- name is %s   ,ID is %d    ,Gender is %s \n", i,Last->name,Last -> value,Last->gender);
		}
	}else{
		printf("List is Empty\n");
	}
	
	printf("----------------------\n\n\n");
	userMode();
}

void cancel(u32 _id)
{
	u8 flag=0;
	for(u8 i =0;i<6;i++)
	{
		if (_id==arrs[i].id)
		{
			/*make it free again*/
			arrs[i].state=0;flag=1;  break;
		}
	}
			if(flag==0){printf("this id isnot found");}
adminMode();
}

void addnew(u32 id)
{           
while(current != NULL)
   {
	   if(current->value == id)
	   {
		   //id found
		   
		   printf("ID %d is already exist  \n", id);
		   return;
	   }
   }
	   
             u8 i=0;u16 age;
       u8 arr[51];u8 gender[7];         
      printf("What is the patient name?\n");
		fflush(stdout);
       scanf(" %[^\n]s",arr);
    	    printf("%s",arr);  
		    printf("What is the patient gender?\n");
			fflush(stdout);
			 scanf(" %[^\n]s",gender);
		    printf("%s",gender);
		    printf("THEN ,What is the patient age?\n");
			fflush(stdout);
	       scanf("%d",&age);
			printf("hi!");
			addNewPet(id,arr,gender,age);
	   adminMode();
   

}
 void addNewPet(u32 id, u8 name[51],u8 gender[7],u8 age)
{   	if (ListLength == 0){
		head.value = id ;
		head.next  = NULL; 
		strcpy(head.name,name);
		strcpy(head.gender,gender);
	}else{
		/* 1- Allocate the new node */
		node *new = (node*) malloc(sizeof(node));
		/* 2- Assign the received value to the new node */
		new -> value = id;
		strcpy(new->gender,gender);
		strcpy(new->name,name);
		/* 3- Make the new node next pointer to Null, as it will 
		be added to the end of the list */
		new -> next  = NULL;
		node *last = &head;
		/* 4- Search for the last node */
		while( (last -> next) != NULL ){
			last = (last -> next); /* go to next node */
		} /* pinter last has address last node */
		/* 5- last node point to new node */
		last -> next = new;
	}
	/* Increase the list length by one node */
	ListLength++;	adminMode();
}

void reserve(u32 _id)
{
	u32 u;
	printf("Dear,    the slots are :\n");
    printf("first slot is at 2 pm  PRESS 0 TO CHOOSE IT\n");
    printf("second slot is at 2:30 pm PRESS 1 TO CHOOSE IT\n");
    printf("third slot is at 3 pm PRESS 2 TO CHOOSE IT\n");
    printf("fourth slot is at 3:30 pm PRESS 3 TO CHOOSE IT\n");
    printf("fifth slot is at 4 pm PRESS 4 TO CHOOSE IT\n");
    printf("sixth slot is at 4:30 pm PRESS 5 TO CHOOSE IT\n");
	printf("When do you want to reserve?\n");
	fflush(stdout);
	scanf("%d",&u);
	
		
    for(u8 i=0;i<6;i++)
	{
		if(i==u)
		{
		if(arrs[i].state==0){arrs[i].id=_id;
		arrs[i].state=1; printf("the slot has been reserved successfully !");break;
		}
		else{printf("this slot id=s reserved before");}
		}
	}
adminMode();	
}
void edit(u32 id)
{   u8 choice;
	 while(current->next != NULL)
   {
      if(current->value==id)
	  {	 
        printf("if you want to edit the name press 1\n");
	    u8*GENDER=(u8*)malloc(sizeof(GENDER)); 
		u8 *NAME=(u8*)malloc(sizeof(u8)*10000);
		printf("if you want to edit the gender press 2\n");			 u8 c=' ';
        printf("if you want to edit the age press 3\n");u8 ag;
		switch(choice)
		{
			case 1: 
			printf("What is the name you want");
			fflush(stdout);
    scanf("%c",&c);   NAME[i++]=c;
	scanf("%c",&c);NAME[i++]=c;
	while(c!='\n'){scanf("%c",&c);  NAME[i++]=c;}
	NAME[i]='\0';
		printf("%s",NAME);
		
			strcpy(current->name,NAME);
			break;
			case 2:
			printf("What is the patient gender?\n");
			fflush(stdout);
			fgets(GENDER,sizeof(GENDER),stdin);
		   puts(GENDER);
		   strcpy(current->gender,GENDER);
			break;
			case 3: 
			printf("What is the patient age?\n");
			fflush(stdout);
			scanf("%d",&ag);
			current->age=ag;
			break;
		}

	  }
   }
   adminMode();
}
void PRintTodayRes(void)
{u8 flag=1;
	for(u8 i=0;i<6;i++)
	{
		if(arrs[i].state==1)
		{
			printf("%d\t",arrs[i].id);
			switch(i)
			{
				case 0: printf("at 2 pm \n"); break;
				case 1: printf("at 2:30 pm \n"); break;
				case 2: printf("at 3 pm \n"); break;
				case 3: printf("at 3:30 pm \n"); break;
				case 4: printf("at 4 pm \n"); break;
				case 5: printf("at 4:30 pm \n"); break;
			}
		}
		else{flag=0;}
	}
	if(flag==0){printf("there is no resrvation!\n");}
userMode();
}